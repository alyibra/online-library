import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import session from 'express-session';
import bcrypt from 'bcrypt';
import db from './db.js'; // Import the database connection
import { insertUser, validateUser } from './models/usermodels.js';
import { fetchBooksByCategory } from './models/bookModel.js';
import * as cartModel from './models/cartModel.js'; // Import cart model functions

// Resolve __filename and __dirname for ES Modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize Express app
const app = express();

// Middleware setup
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(
  session({
    secret: 'fallback-default-secret',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false }, // Set to `true` for HTTPS
  })
);

// Serve static files
app.use(express.static(path.join(__dirname, 'public')));

// Configure EJS as the view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Debugging paths
console.log('Resolved views path:', path.join(__dirname, 'views'));
console.log('Resolved public path:', path.join(__dirname, 'public'));

// Middleware to check if the user is logged in
const isAuthenticated = (req, res, next) => {
  if (!req.session.userId) {
    return res.redirect('/');
  }
  next();
};

// Routes

// Render registration page
app.get('/', (req, res) => {
  res.render('register');
});

// Handle registration
app.post('/register', async (req, res) => {
  const { username, email, password, isAdmin, adminPassword } = req.body;

  try {
    // 1. Check if email already exists
    const [existing] = await db.query('SELECT Email FROM users WHERE Email = ?', [email]);
    if (existing.length > 0) {
      // Email already registered
      return res.status(400).json({ message: 'Email already exists' });
    }

    // 2. If user wants admin privileges, validate admin password
    if (isAdmin && adminPassword !== 'admin1234') {
      return res.status(400).json({ message: 'Invalid admin password' });
    }

    // 3. Hash password and insert user
    const hashedPassword = await bcrypt.hash(password, 10);

    await db.query(
      'INSERT INTO users (Username, Email, PasswordHash, isAdmin) VALUES (?, ?, ?, ?)',
      [username, email, hashedPassword, isAdmin ? 1 : 0]
    );

    // Return success
    return res.status(200).json({ message: 'Registration successful' });
  } catch (error) {
    console.error('Error during registration:', error);
    return res.status(500).json({ message: 'Server error. Please try again later.' });
  }
});


// Handle login
app.post('/login', async (req, res) => {
  const { email, password } = req.body;

  try {
    // Fetch user by email
    const query = 'SELECT * FROM users WHERE Email = ?';
    const [users] = await db.query(query, [email]);

    if (users.length === 0) {
      return res.status(400).send('<h1>Invalid email or password!</h1><p><a href="/">Try again</a></p>');
    }

    const user = users[0];

    // Check password
    const isPasswordValid = await bcrypt.compare(password, user.PasswordHash);
    if (!isPasswordValid) {
      return res.status(400).send('<h1>Invalid email or password!</h1><p><a href="/">Try again</a></p>');
    }

    // Store user details in session
    req.session.userId = user.UserID;
    req.session.username = user.Username;
    req.session.isAdmin = user.isAdmin === 1; // Ensure isAdmin is boolean

    // Redirect based on role
    if (req.session.isAdmin) {
      return res.redirect('/admin'); // Admin page
    }

    res.redirect('/HomePage'); // Direct to home page instead of welcome
  } catch (error) {
    console.error('Error during login:', error);
    res.status(500).send('<h1>Server error. Please try again later.</h1>');
  }
});


// Welcome page route removed - users now go directly to HomePage

// Render homepage
app.get('/HomePage', isAuthenticated, (req, res) => {
  res.render('HomePage');
});

// Fetch books by category
app.get('/books-:category', async (req, res) => {
  const category = req.params.category;

  try {
    const books = await fetchBooksByCategory(category);
    res.render('category', { categoryName: category, books });
  } catch (error) {
    console.error(`Error fetching books for category "${category}":`, error);
    res.status(500).send('Error fetching books.');
  }
});

// Random books (300 books)
app.get('/random-books', async (req, res) => {
  try {
    const query = `
      SELECT BookID, Title, Author, Price, imageURL 
      FROM books 
      ORDER BY RAND() 
      LIMIT 50
    `;
    const [books] = await db.query(query);
    res.json({ books });
  } catch (error) {
    res.status(500).json({ error: 'Error fetching random books' });
  }
});



// Render book details and order page
app.get('/buy/:bookId', async (req, res) => {
  const bookId = req.params.bookId;

  try {
    const query = 'SELECT * FROM books WHERE BookID = ?';
    const [bookDetails] = await db.query(query, [bookId]);

    if (bookDetails.length === 0) {
      return res.status(404).send('<h1>Book not found</h1>');
    }

    res.render('order', { book: bookDetails[0] });
  } catch (error) {
    console.error('Error fetching book details:', error);
    res.status(500).send('<h1>Error loading book details</h1>');
  }
});

// Render cart page
app.get('/cart', isAuthenticated, async (req, res) => {
  const userId = req.session.userId;

  try {
    const cartItems = await cartModel.getCartItemsForUser(userId);
    const cartTotal = cartItems.length > 0 ? await cartModel.calculateCartTotal(cartItems) : 0;

    // Assuming lastVisitedCategory is stored in the session
    const lastVisitedCategory = req.session.lastVisitedCategory || 'default';

    res.render('cart', { cartItems, carttotal: cartTotal, lastVisitedCategory });
  } catch (error) {
    console.error('Error fetching cart items:', error);
    res.status(500).send('Error fetching cart items.');
  }
});


// Add to cart
app.post('/add-to-cart', async (req, res) => {
  const userId = req.session.userId;
  const { bookId, quantity = 1 } = req.body;

  try {
    // 1. Check if the item exists
    const [existingRows] = await db.query(
      'SELECT * FROM cart WHERE UserID = ? AND BookID = ?',
      [userId, bookId]
    );

    if (existingRows.length > 0) {
      // 2. If it exists, update quantity
      await db.query(
        'UPDATE cart SET Quantity = Quantity + ? WHERE UserID = ? AND BookID = ?',
        [quantity, userId, bookId]
      );
      return res.json({ message: 'Book quantity incremented successfully' });
    } else {
      // 3. If it doesn't exist, insert as new
      await db.query(
        'INSERT INTO cart (UserID, BookID, Quantity, Format) VALUES (?, ?, ?, "hardcopy")',
        [userId, bookId, quantity]
      );
      return res.json({ message: 'Book added to cart successfully' });
    }
  } catch (error) {
    console.error('Error adding book to cart:', error);
    return res.status(500).json({ message: 'Error adding book to cart' });
  }
});




app.post('/cart/increase', async (req, res) => {
  const { cartItemId } = req.body;
  console.log('Increase request received for cartItemId:', cartItemId);

  if (!cartItemId) {
      console.error('Cart item ID is missing.');
      return res.status(400).json({ success: false, message: 'Cart item ID is required.' });
  }

  try {
      const result = await cartModel.increaseCartItemQuantity(cartItemId);
      console.log('Quantity increased. New quantity:', result.newQuantity);
      res.json({ success: true, newQuantity: result.newQuantity });
  } catch (error) {
      console.error('Error increasing cart item quantity:', error.message);
      res.status(500).json({ success: false, message: 'Error increasing cart item quantity.' });
  }
});
app.post('/cart/decrease', async (req, res) => {
  const { cartItemId } = req.body;
  console.log('Decrease request received for cartItemId:', cartItemId);

  if (!cartItemId) {
      console.error('Cart item ID is missing.');
      return res.status(400).json({ success: false, message: 'Cart item ID is required.' });
  }

  try {
      const result = await cartModel.decreaseCartItemQuantity(cartItemId);
      console.log('Quantity decreased. New quantity:', result.newQuantity);
      res.json({ success: true, newQuantity: result.newQuantity });
  } catch (error) {
      console.error('Error decreasing cart item quantity:', error.message);
      res.status(500).json({ success: false, message: 'Error decreasing cart item quantity.' });
  }
});



// Remove item from cart
app.post('/cart/delete', async (req, res) => {
  const { cartItemId } = req.body;

  if (!cartItemId) {
    return res.status(400).json({ success: false, message: 'Cart item ID is required.' });
  }

  try {
    await cartModel.deleteCartItem(cartItemId);
    res.json({ success: true, message: 'Item removed from cart.' });
  } catch (error) {
    console.error('Error deleting cart item:', error);
    res.status(500).json({ success: false, message: 'Error deleting cart item.' });
  }
});

app.get('/checkout', isAuthenticated, (req, res) => {
  res.render('checkout'); // Render the checkout page
});

// app.post('/complete-order', isAuthenticated, async (req, res) => {
//   const userId = req.session.userId;
//   const { address, phone } = req.body;

//   try {
//     // Get all cart items for the user
//     const cartItems = await cartModel.getCartItemsForUser(userId);

//     if (cartItems.length === 0) {
//       return res.status(400).send('<h1>Your cart is empty!</h1><a href="/cart">Go back to cart</a>');
//     }

//     // Loop through cart items to update stock and save order details
//     for (const item of cartItems) {
//       // Check if enough stock is available
//       if (item.Quantity > item.stock) {
//         return res.status(400).send(`<h1>Not enough stock for ${item.Title}. Only ${item.stock} left in stock.</h1><a href="/cart">Go back to cart</a>`);
//       }

//       // Update the stock in the database
//       await db.query('UPDATE books SET stock = stock - ? WHERE BookID = ?', [item.Quantity, item.BookID]);

//       // Save the order in the database
//       await db.query(
//         'INSERT INTO orders (UserID, BookID, Quantity, Address, Phone, TotalPrice) VALUES (?, ?, ?, ?, ?, ?)',
//         [userId, item.BookID, item.Quantity, address, phone, item.Quantity * item.Price]
//       );
//     }

//     // Clear the cart after completing the order
//     await db.query('DELETE FROM cart WHERE UserID = ?', [userId]);

//     res.send('<h1>Order placed successfully!</h1><a href="/HomePage">Continue Shopping</a>');
//   } catch (error) {
//     console.error('Error completing order:', error);
//     res.status(500).send('<h1>Error completing order. Please try again later.</h1>');
//   }
// });


app.get('/search-books', async (req, res) => {
  const query = req.query.query;

  if (!query) {
      return res.status(400).json({ books: [] });
  }

  try {
      const searchQuery = `
          SELECT BookID, Title, Author 
          FROM books 
          WHERE Title LIKE ? OR Author LIKE ?
          LIMIT 10
      `;
      const [books] = await db.query(searchQuery, [`%${query}%`, `%${query}%`]);
      res.json({ books });
  } catch (error) {
      console.error("Error fetching search results:", error);
      res.status(500).json({ books: [] });
  }
});

// Render book details page
app.get('/book/:bookId', async (req, res) => {
  const bookId = req.params.bookId;

  try {
    const query = 'SELECT * FROM books WHERE BookID = ?';
    const [bookDetails] = await db.query(query, [bookId]);

    if (bookDetails.length === 0) {
      return res.status(404).send('<h1>Book not found</h1>');
    }

    res.render('bookDetails', { book: bookDetails[0] });
  } catch (error) {
    console.error('Error fetching book details:', error);
    res.status(500).send('<h1>Error loading book details</h1>');
  }
});


//admin////////////////////////


const isAdmin = (req, res, next) => {
  if (!req.session.userId || !req.session.isAdmin) {
    return res.status(403).send('<h1>Access Denied</h1><p>You do not have permission to access this page.</p>');
  }
  next();
};




// Render admin page
app.get('/admin', isAdmin, async (req, res) => {
  try {
    const [books] = await db.query('SELECT * FROM books');
    res.render('admin', { books, username: req.session.username });
  } catch (error) {
    console.error('Error loading admin page:', error);
    res.status(500).send('<h1>Error loading admin page</h1>');
  }
});


// Add a new book
app.post('/admin/add-book', isAdmin, async (req, res) => {
  const { title, author, description, price, stock, imageURL } = req.body;

  try {
    const query = `
      INSERT INTO books (Title, Author, Description, Price, stock, imageURL)
      VALUES (?, ?, ?, ?, ?, ?)
    `;
    await db.query(query, [title, author, description, price, stock, imageURL]);
    res.redirect('/admin');
  } catch (error) {
    console.error('Error adding book:', error);
    res.status(500).send('<h1>Error adding book</h1>');
  }
});

// Delete a book
app.post('/admin/delete-book/:bookId', isAdmin, async (req, res) => {
  const bookId = req.params.bookId;

  try {
    await db.query('DELETE FROM books WHERE BookID = ?', [bookId]);
    res.redirect('/admin');
  } catch (error) {
    console.error('Error deleting book:', error);
    res.status(500).send('<h1>Error deleting book</h1>');
  }
});

// Edit a book
app.post('/admin/edit-book/:bookId', isAdmin, async (req, res) => {
  const bookId = req.params.bookId;
  const { title, author, description } = req.body;

  try {
    const query = `
      UPDATE books
      SET Title = ?, Author = ?, Description = ?
      WHERE BookID = ?
    `;
    await db.query(query, [title, author, description, bookId]);
    res.redirect('/admin');
  } catch (error) {
    console.error('Error editing book:', error);
    res.status(500).send('<h1>Error editing book</h1>');
  }
});




// Logout Route
app.get('/logout', (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      console.error('Error destroying session:', err);
      return res.status(500).send('Internal Server Error');
    }
    // After session is destroyed, redirect to registration page (root path)
    res.redirect('/');
  });
});



//-----------------------------------
// Example using Express and MySQL
app.get('/api/get-messages', async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM messages ORDER BY created_at DESC'); // 
    return res.json({ messages: rows });
  } catch (error) {
    console.error('Error fetching messages:', error);
    return res.status(500).json({ error: 'Failed to fetch messages.' });
  }
});




app.get('/logout', (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      console.error('Error destroying session:', err);
      return res.status(500).send('Internal Server Error');
    }
    // Redirect user to registration page (assuming it is at "/")
    res.redirect('/');
  });
});


app.get('/cart', isAuthenticated, async (req, res) => {
  // If using a cartModel or similar
  const userId = req.session.userId;
  const cartItems = await cartModel.getCartItemsForUser(userId);
  const cartTotal = cartItems.length > 0 ? await cartModel.calculateCartTotal(cartItems) : 0;
  res.render('cart', { cartItems, carttotal: cartTotal });
});

app.post('/contact', async (req, res) => {
  try {
    const { name, email, message } = req.body;

    const insertQuery = 'INSERT INTO messages (name, email, message) VALUES (?, ?, ?)';
    await db.query(insertQuery, [name, email, message]);

    // Return a simple success status
    res.status(200).json({ message: 'Message stored successfully' });
  } catch (error) {
    console.error('Error saving message:', error);
    res.status(500).json({ error: 'Failed to save message' });
  }
});



// Example for fetching random books:
app.get('/random-books', async (req, res) => {
  try {
    const query = `
      SELECT BookID, Title, Author, Price, Discount, imageURL 
      FROM books
      ORDER BY RAND()
      LIMIT 50
    `;
    const [books] = await db.query(query);
    res.json({ books });
  } catch (error) {
    console.error('Error fetching random books:', error);
    res.status(500).json({ error: 'Error fetching random books' });
  }
});


// In your server code (e.g., index.js)
app.get('/api/finance', async (req, res) => {
  try {
    // 1) Summaries: total sales, total orders
    const [rowsSum] = await db.query(`
      SELECT SUM(TotalPrice) AS totalSales, COUNT(*) AS totalOrders
      FROM orders
    `);
    const totalSales = rowsSum[0]?.totalSales || 0;
    const totalOrders = rowsSum[0]?.totalOrders || 0;

    // 2) Category sales
    const [rowsCategory] = await db.query(`
      SELECT b.CATALOG_NAME AS categoryName,
             SUM(o.Quantity) AS unitsSold,
             SUM(o.TotalPrice) AS totalSales
      FROM orders o
      JOIN books b ON o.BookID = b.BookID
      GROUP BY b.CATALOG_NAME
      ORDER BY totalSales DESC
    `);

    // 3) Top Selling Books
    const [rowsTopBooks] = await db.query(`
      SELECT b.Title,
             SUM(o.Quantity) AS unitsSold,
             SUM(o.TotalPrice) AS revenue
      FROM orders o
      JOIN books b ON o.BookID = b.BookID
      GROUP BY b.BookID
      ORDER BY revenue DESC
      LIMIT 5
    `);

    // Summaries
    const topCategory = rowsCategory.length > 0 ? rowsCategory[0].categoryName : 'N/A';
    const topBook = rowsTopBooks.length > 0 ? rowsTopBooks[0].Title : 'N/A';

    res.json({
      totalSales,
      totalOrders,
      topCategory,
      topBook,
      categorySales: rowsCategory,
      topBooks: rowsTopBooks,
    });
  } catch (error) {
    console.error('Error fetching finance data:', error);
    res.status(500).json({ error: 'Failed to fetch finance data' });
  }
});


app.get('/api/book/:bookId', async (req, res) => {
  try {
    const bookId = req.params.bookId;
    const [rows] = await db.query('SELECT * FROM books WHERE BookID = ?', [bookId]);

    if (!rows.length) {
      return res.status(404).json({ error: 'Book not found' });
    }

    res.json(rows[0]); // Return the first row
  } catch (error) {
    console.error('Error fetching book details:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});


// Example server route (Node/Express)
app.get('/api/book/:bookId', async (req, res) => {
  try {
    const bookId = req.params.bookId;
    const [rows] = await db.query('SELECT * FROM books WHERE BookID = ?', [bookId]);
    if (!rows.length) {
      return res.status(404).json({ error: 'Book not found' });
    }
    res.json(rows[0]); // This includes the (long) Description or DetailedDescription
  } catch (error) {
    console.error('Error fetching book details:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});


app.get('/tracking/:trackingId', async (req, res) => {
  const trackingId = req.params.trackingId;

  try {
    // Query to fetch user’s purchased books for that trackingId
    // Example:
    const [orderItems] = await db.query(`
      SELECT 
        o.BookID,
        o.Quantity,
        o.Price,
        b.Title
      FROM orders o
      JOIN books b ON o.BookID = b.BookID
      WHERE o.trackingId = ?
    `, [trackingId]);

    // Suppose you also stored order status or you keep "Processing", "Shipped" states
    const status = 'Processing';            // or from DB
    const estimatedDelivery = '3-5 days';   // or from DB

    // Render the tracking page
    res.render('tracking', {
      trackingId,
      orderItems,
      status,
      estimatedDelivery
    });
  } catch (error) {
    console.error('Error fetching tracking data:', error);
    res.status(500).send('Failed to retrieve order details.');
  }
});


// Example in your complete-order route
app.post('/complete-order', async (req, res) => {
  const userId = req.session.userId;
  const { address, phone } = req.body;

  try {
    // 1) Fetch cart items for user
    const cartItems = await cartModel.getCartItemsForUser(userId);
    if (cartItems.length === 0) {
      return res.status(400).send('No items in cart.');
    }

    // 2) Create unique tracking ID or Order ID
    const trackingId = 'TRACK-' + Date.now();

    // 3) Insert each cart item into "orders" table
    for (const item of cartItems) {
      // Insert row for each book
      // Example: 
      await db.query(`
        INSERT INTO orders (trackingId, UserID, BookID, Quantity, Price, Address, Phone, Status)
        VALUES (?, ?, ?, ?, ?, ?, ?, 'Processing')
      `, [
        trackingId,
        userId,
        item.BookID,
        item.Quantity,
        item.Price,
        address,
        phone
      ]);

      // Also decrement stock in `books` if needed
      await db.query('UPDATE books SET stock = stock - ? WHERE BookID = ?', [item.Quantity, item.BookID]);
    }

    // 4) Clear the user’s cart
    await db.query('DELETE FROM cart WHERE UserID = ?', [userId]);

    // 5) Return the tracking ID to the client (JSON or redirect)
    // For a JSON approach:
    res.status(200).json({ trackingId });
  } catch (error) {
    console.error('Error completing order:', error);
    res.status(500).json({ message: 'Error processing your order.' });
  }
});


// Start the server
const PORT = 4000;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
