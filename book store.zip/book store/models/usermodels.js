import db from '../db.js'; // Ensure the path to your db.js file is correct
import bcrypt from 'bcrypt'; // For password hashing and validation

const insertUser = (username, email, passwordHash, isAdmin, adminPassword, callback) => {
  // Verify admin password if registering as admin
  if (isAdmin && adminPassword !== 'admin1234') {
    return callback(new Error('Invalid admin password'));
  }

  // Query to insert the user with the isAdmin field
  const query = 'INSERT INTO users (Username, Email, PasswordHash, isAdmin) VALUES (?, ?, ?, ?)';
  db.query(query, [username, email, passwordHash, isAdmin], (err, result) => {
    if (err) {
      console.error('Error inserting user into database:', err); // Debugging database errors
      return callback(err);
    }

    console.log('User successfully inserted:', result); // Debugging successful insert
    callback(null, result);
  });
};

const validateUser = async (email, password, callback) => {
  try {
    // Query to find the user by email
    const query = 'SELECT * FROM users WHERE Email = ?';
    const [results] = await db.query(query, [email]);

    console.log('Database query results for email:', results); // Debugging query results

    if (results.length === 0) {
      console.log('No user found with the given email'); // Email not found
      return callback(null, null); // Return null for no user found
    }

    const user = results[0]; // Get the first user record
    console.log('User fetched from database:', user); // Debugging fetched user record

    // Compare the entered password with the stored hashed password
    const isValidPassword = await bcrypt.compare(password, user.PasswordHash);
    console.log('Password comparison result:', isValidPassword); // Debugging password comparison

    if (!isValidPassword) {
      console.log('Password does not match'); // Debugging invalid password
      return callback(null, null); // Return null for invalid password
    }

    console.log('User validated successfully'); // Debugging successful login
    callback(null, user); // Return the user object if credentials are valid
  } catch (error) {
    console.error('Error during user validation:', error);
    callback(error); // Handle unexpected errors
  }
};

// Export the functions
export { insertUser, validateUser };
