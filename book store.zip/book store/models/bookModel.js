import db from '../db.js';

export async function fetchBooksByCategory(categoryName) {
  const query = `
    SELECT 
      BookID, Title, Author, Description, Price, SoftCopyURL, 
      CreatedAt, stock, sales_count, CATALOG_NAME, image, imageURL
    FROM books
    WHERE CATALOG_NAME = ?;
  `;

  try {
    const [rows] = await db.query(query, [categoryName]); // Use promise-based query
    console.log('Books fetched by category:', rows);
    return rows;
  } catch (error) {
    console.error('Error fetching books by category:', error);
    throw error;
  }
}
