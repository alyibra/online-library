import db from "../db.js";

export async function addToCart(userId, bookId) {
  const query = `
    INSERT INTO cart(UserID, BookID, Quantity, Format) 
    VALUES (?, ?, 1, 'hardcopy') 
    ON DUPLICATE KEY UPDATE Quantity = LEAST(Quantity + 1, (SELECT stock FROM books WHERE BookID = ?))
  `;
  try {
    await db.query(query, [userId, bookId, bookId]);
  } catch (error) {
    throw new Error(`Error adding book to cart: ${error}`);
  }
}

export async function getCartItemsForUser(userId) {
  const query = `
    SELECT c.CartItemID, c.UserID, c.BookID, c.Quantity, c.Format, 
           b.Title, b.Author, b.Price, b.imageURL, b.stock
    FROM cart c
    JOIN books b ON c.BookID = b.BookID
    WHERE c.UserID = ?
  `;
  try {
    const [rows] = await db.query(query, [userId]);
    return rows;
  } catch (err) {
    throw new Error(`Error fetching cart items: ${err.message}`);
  }
}

export async function calculateCartTotal(cartItems) {
  return cartItems.reduce((total, item) => {
    if (item.Quantity <= item.stock) {
      return total + item.Price * item.Quantity;
    } else {
      throw new Error(`Requested quantity for ${item.Title} exceeds available stock.`);
    }
  }, 0);
}

export async function increaseCartItemQuantity(cartItemId) {
  const queryCheckStock = `
      SELECT Quantity, BookID FROM cart WHERE CartItemID = ?;
  `;
  const queryGetStock = `
      SELECT stock FROM books WHERE BookID = ?;
  `;
  const queryUpdateQuantity = `
      UPDATE cart SET Quantity = Quantity + 1 WHERE CartItemID = ? AND Quantity < ?;
  `;

  try {
    const [cartRows] = await db.query(queryCheckStock, [cartItemId]);
    if (cartRows.length === 0) {
      throw new Error('Cart item not found.');
    }

    const cartItem = cartRows[0];
    const [bookRows] = await db.query(queryGetStock, [cartItem.BookID]);
    if (bookRows.length === 0) {
      throw new Error('Book not found.');
    }

    const bookStock = bookRows[0].stock;
    if (cartItem.Quantity >= bookStock) {
      throw new Error(`Stock limit reached. Only ${bookStock} available.`);
    }

    await db.query(queryUpdateQuantity, [cartItemId, bookStock]);
    const newQuantity = cartItem.Quantity + 1;
    return { newQuantity };
  } catch (error) {
    throw new Error(error.message || 'Error increasing cart item quantity.');
  }
}

export async function decreaseCartItemQuantity(cartItemId) {
  try {
    await db.query('UPDATE cart SET Quantity = Quantity - 1 WHERE CartItemID = ? AND Quantity > 1', [cartItemId]);
    const [rows] = await db.query('SELECT Quantity FROM cart WHERE CartItemID = ?', [cartItemId]);
    return { newQuantity: rows[0]?.Quantity || 0 };
  } catch (error) {
    throw new Error(`Error decreasing cart item quantity: ${error.message}`);
  }
}

export async function deleteCartItem(cartItemId) {
  try {
    await db.query('DELETE FROM cart WHERE CartItemID = ?', [cartItemId]);
  } catch (error) {
    throw new Error(`Error deleting cart item: ${error.message}`);
  }
}
