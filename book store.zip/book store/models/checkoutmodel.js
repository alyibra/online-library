
import db from '../db.js';

app.post('/checkout', async (req, res) => {
    try {
      const cart = req.session.cart || [];
      if (cart.length === 0) {
        return res.redirect('/cart'); // Redirect back to cart if empty
      }
  
      // Process each item in the cart (e.g., reduce stock, save order)
      for (const item of cart) {
        // Reduce stock in the database
        await db.query('UPDATE books SET stock = stock - ? WHERE BookID = ?', [item.quantity, item.bookId]);
  
        // Save the order details in the database
        await db.query(
          'INSERT INTO orders (BookID, Quantity, Price, UserID) VALUES (?, ?, ?, ?)',
          [item.bookId, item.quantity, item.price, req.session.userId || null]
        );
      }
  
      // Clear the cart after checkout
      req.session.cart = [];
  
      res.send('<h1>Order placed successfully!</h1><p>Thank you for your purchase. <a href="/">Continue shopping</a></p>');
    } catch (error) {
      console.error('Error during checkout:', error);
      res.status(500).send('<h1>Error during checkout. Please try again later.</h1>');
    }
  });
  
  app.post('/cart/add', (req, res) => {
    const { bookId, title, price } = req.body;
  
    // Initialize the cart in session if it doesn't exist
    if (!req.session.cart) {
      req.session.cart = [];
    }
  
    // Add the book to the cart
    const book = {
      bookId,
      title,
      price: parseFloat(price),
      quantity: 1, // Default quantity is 1
    };
  
    // Check if the book is already in the cart
    const existingBook = req.session.cart.find(item => item.bookId === bookId);
    if (existingBook) {
      existingBook.quantity += 1; // Increment quantity if already in cart
    } else {
      req.session.cart.push(book); // Add new book to cart
    }
  
    // Redirect back to the books page or the current page
    res.redirect('back');
  });