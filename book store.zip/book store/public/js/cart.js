document.addEventListener('DOMContentLoaded', () => {
    const updateCartTotal = () => {
      let total = 0;
      document.querySelectorAll('.cart-item').forEach(item => {
        const price = parseFloat(item.querySelector('.price').textContent);
        const quantity = parseInt(item.querySelector('.quantity').textContent);
        total += price * quantity;
      });
      document.getElementById('cart-total').textContent = total.toFixed(2);
    };
  
    // Increase quantity
    document.querySelectorAll('.increase-qty').forEach(button => {
      button.addEventListener('click', async (e) => {
        const cartItem = e.target.closest('.cart-item');
        const cartItemId = cartItem.dataset.cartItemId;
  
        try {
          const response = await fetch('/cart/increase', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ cartItemId }),
          });
  
          const result = await response.json();
          if (response.ok) {
            cartItem.querySelector('.quantity').textContent = result.newQuantity;
            updateCartTotal();
          } else {
            alert(result.message || 'Cannot increase quantity.');
          }
        } catch (error) {
          console.error('Error increasing quantity:', error);
        }
      });
    });
  
    // Decrease quantity
    document.querySelectorAll('.decrease-qty').forEach(button => {
      button.addEventListener('click', async (e) => {
        const cartItem = e.target.closest('.cart-item');
        const cartItemId = cartItem.dataset.cartItemId;
  
        try {
          const response = await fetch('/cart/decrease', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ cartItemId }),
          });
  
          const result = await response.json();
          if (response.ok) {
            if (result.newQuantity > 0) {
              cartItem.querySelector('.quantity').textContent = result.newQuantity;
            } else {
              cartItem.remove();
            }
            updateCartTotal();
          } else {
            alert(result.message || 'Failed to update quantity.');
          }
        } catch (error) {
          console.error('Error decreasing quantity:', error);
        }
      });
    });
  
    // Remove item
    document.querySelectorAll('.remove-btn').forEach(button => {
      button.addEventListener('click', async (e) => {
        const cartItem = e.target.closest('.cart-item');
        const cartItemId = cartItem.dataset.cartItemId;
  
        try {
          const response = await fetch('/cart/delete', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ cartItemId }),
          });
  
          if (response.ok) {
            cartItem.remove();
            updateCartTotal();
          }
        } catch (error) {
          console.error('Error removing item:', error);
        }
      });
    });
  });
  